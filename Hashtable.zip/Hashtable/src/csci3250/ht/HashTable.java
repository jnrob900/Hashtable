//Robert Jones
//Saeid Samadidana
//Assignment 5
//11/25/2020


package csci3250.ht;
import java.util.LinkedList;

/**
*
* @author jnrob
*/
public class HashTable //hashtable function
{

   private final int BUCKET;
   private final LinkedList<Integer>[] Hashtable;
   public int hashFunction(int x)
   {
       return x % BUCKET;
   }
  
   public HashTable(int b) 
   {
       this.BUCKET = b;
       Hashtable = new LinkedList[b];
   }
  
   public void insertItem(int key) //insert a interger
   {
       int index = hashFunction(key);
       if (Hashtable[index] == null)
           Hashtable[index] = new LinkedList<>();
      
       if (!Hashtable[index].contains(key))
           Hashtable[index].add(key);
   }
  
   public void deleteItem(Integer key) //to delete an interger
   {
       int index = hashFunction(key);
       if (Hashtable[index] != null && Hashtable[index].contains(key))
           Hashtable[index].remove(key);
   }
  
   public void displayHash() //functin to display your intergers
   {
       for (int i = 0; i < BUCKET; ++i)
       {
           System.out.print(i);
           if (Hashtable[i] != null)
           {
               for (int ele : Hashtable[i])
                   System.out.print(" -> " + ele);
           }
           System.out.println();
       }
   }

}