//Robert Jones
//Saeid Samadidana
//Assignment 5
//11/25/2020


package csci3250.ht; //package name

import java.util.Scanner;


public class Hashtabledemo
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) //main fuction
    {
       Scanner sc = new Scanner(System.in);
       int n;  //variable to read in a number
       System.out.println("******************Welcome to my Hashtable********************");
       System.out.print("Enter the table size: ");
       n = sc.nextInt();
       HashTable h;
       h = new HashTable(n);
       int i;   //variables
       int choice,key;
       while (true)
{

System.out.println("Please pick a choice from below");
System.out.println("1.Insert element");   //prints the following
System.out.println("2.Delete element");
System.out.println("3.Display Table");
System.out.println("4.Exit");
System.out.print("Enter your choice: ");
choice = sc.nextInt();
  
switch(choice)  //choices to pick from
{
case 1: System.out.println("Insert the key: ");
i = sc.nextInt();
h.insertItem(i);
break;
case 2: System.out.print("Enter the key to delete: ");
key = sc.nextInt();   
h.deleteItem(key);
break;
case 3: h.displayHash();
break;
case 4: sc.close();
System.exit(0);
default:
System.out.println("\nInvalid Option");
}
}
    }
}
  





    
    
